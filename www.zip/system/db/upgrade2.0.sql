ALTER TABLE eps_user DROP resetTime;
