<?php
/**
 * The article category zh-tw file of chanzhiEPS.
 *
 * @copyright   Copyright 2013-2013 青島息壤網絡信息有限公司 (QingDao XiRang Network Infomation Co,LTD www.xirangit.com)
 * @license     http://api.chanzhi.org/goto.php?item=license
 * @author      Xiying Guan <guanxiying@xirangit.com>
 * @package     blog
 * @version     $Id$
 * @link        http://www.chanzhi.org
 */
$lang->blog->common    = '博客';
$lang->blog->home      = '博客首頁';
$lang->blog->siteHome  = '網站首頁';
$lang->blog->subscribe = '訂閲博客';
