<?php
$lang->error = new stdclass();
$lang->error->pageNotFound    = 'Page not found';
$lang->error->articleCategory = 'Browse articles';
$lang->error->productCategory = 'Browse products';
$lang->error->blogCategory    = 'Browse blog';
