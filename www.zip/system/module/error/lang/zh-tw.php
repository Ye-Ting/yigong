<?php
$lang->error = new stdclass();
$lang->error->pageNotFound    = '頁面不存在';
$lang->error->articleCategory = '文章分類';
$lang->error->productCategory = '產品分類';
$lang->error->blogCategory    = '博客分類';
