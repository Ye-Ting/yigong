<?php
$lang->error = new stdclass();
$lang->error->pageNotFound    = '页面不存在';
$lang->error->articleCategory = '文章分类';
$lang->error->productCategory = '产品分类';
$lang->error->blogCategory    = '博客分类';
