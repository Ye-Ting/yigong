<?php
$config->links->editor = new stdclass();
$config->links->editor->admin = array('id' => 'index,all', 'tools' => 'full');
