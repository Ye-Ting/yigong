<?php
/**
 * The links category zh-tw file of chanzhiEPS.
 *
 * @copyright   Copyright 2013-2013 青島息壤網絡信息有限公司 (QingDao XiRang Network Infomation Co,LTD www.xirangit.com)
 * @license     http://api.chanzhi.org/goto.php?item=license
 * @author      Tingting Dai <daitingting@cnezsoft.com>
 * @package     links
 * @version     $Id$
 * @link        http://www.chanzhi.org
 */
$lang->links->common  = '友情連結';
$lang->links->index   = '首頁連結';
$lang->links->all     = '所有連結';
