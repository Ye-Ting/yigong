<?php
/**
 * The index module simplified chinese file of chanzhiEPS.
 *
 * @copyright   Copyright 2013-2013 青岛息壤网络信息有限公司 (QingDao XiRang Network Infomation Co,LTD www.xirangit.com)
 * @license     http://api.chanzhi.org/goto.php?item=license
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     chanzhiEPS
 * @version     $Id$
 * @link        http://www.chanzhi.org
 */
$lang->index->common  = 'Home';
$lang->index->index   = 'Home';
$lang->index->aboutus = 'About';
$lang->index->news    = 'News';
$lang->index->blog    = 'Blogs';
$lang->index->contact = 'Contact';
