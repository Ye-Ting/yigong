<?php
/**
 * The index module simplified chinese file of chanzhiEPS.
 *
 * @copyright   Copyright 2013-2013 青岛息壤网络信息有限公司 (QingDao XiRang Network Infomation Co,LTD www.xirangit.com)
 * @license     http://api.chanzhi.org/goto.php?item=license
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     chanzhiEPS
 * @version     $Id$
 * @link        http://www.chanzhi.org
 */
$lang->index->common  = '首页';
$lang->index->index   = '首页';
$lang->index->aboutus = '关于我们';
$lang->index->news    = '新闻动态';
$lang->index->blog    = '最近博客';
$lang->index->contact = '联系我们';
