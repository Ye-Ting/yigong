<?php
$config->file->require = new stdclass();
$config->file->require->edit = 'title';

$config->file->thumbs = array();
$config->file->thumbs['s'] = array('width' => '80',  'height' => '80');
$config->file->thumbs['m'] = array('width' => '300', 'height' => '300');
$config->file->thumbs['l'] = array('width' => '800', 'height' => '600');

$config->file->imageExtensions = array('jpeg', 'jpg', 'gif', 'png');

$config->file->mimes['default'] = 'application/octet-stream';
