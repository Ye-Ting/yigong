$(document).ready(function()
{
    if(v.wholeResult == 'ok')
    {
        $('.hide-on-ok').remove();
    }
});
