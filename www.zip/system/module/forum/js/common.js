$(document).ready(function()
{
    $('.nav-system-forum').addClass('active');
})
