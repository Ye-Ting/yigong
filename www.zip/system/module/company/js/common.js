$(document).ready(function()
{
    $('.nav-system-company:first').addClass('active');
});
